-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 22, 2016 at 04:15 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ato`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_question_bank`
--

CREATE TABLE `tbl_question_bank` (
  `count` int(11) NOT NULL,
  `Question` longtext NOT NULL,
  `options` mediumtext NOT NULL,
  `correct_option` int(11) NOT NULL,
  `type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_question_bank`
--

INSERT INTO `tbl_question_bank` (`count`, `Question`, `options`, `correct_option`, `type`) VALUES
(1, '1+1 = ', '1-> two 2-> three ->0', 1, 1),
(2, '3+5=', '1->seven 2-> eight 3-> nine', 2, 1),
(3, '5+5=', '1-> five 2-> zero 3-> eight 4-> ten', 4, 1),
(4, '11 + 22 =', '1-> (33) 2-> (55) 3->(21) 4-> (32)', 1, 2),
(5, '55 + 12 =', '1-> (64) 2-> (65) 3-> (66) 4-> (67) 5->(68)', 4, 2),
(6, '24 + 42 =', '1-> (64) 2-> (65) 3-> (66) 4-> (67) 5->(68)', 3, 2),
(7, '30 + 03 =', '1-> (30) 2-> (0) 3-> (90) 4->(33)', 4, 2),
(8, '452 - 341 =', '1-> (111) 2->(222) 3-> (333) 4->(11)', 1, 3),
(9, '999 - 199 = ', '1-> (700) 2-> (800) 3-> (799) 4-> (899)', 2, 3),
(10, '812 - 921 =', '1-> (109) 2-> (111) 3->(-109) 4-> (-111)', 3, 3),
(11, '452 - 382 =', '1-> (60) 2-> (70) 3->(80) 4-> (90)', 2, 3),
(12, 'What is the name of connector which connects usb to mobile?', '1-> GTA 2-> Data Card 3-> OTG 4-> Card reader', 3, 4),
(13, 'Whch option does Windows operationg 10 System turns off?', '1-> shut down 2-> shut up 3-> turn off 4-> hibernate', 1, 4),
(14, 'What is the android application extension?', '1-> .exe 2->.rar 3->.android 4->.apk', 4, 4),
(15, 'what is the use of biometric sensor in electronic device?', '1-> Detect face 2-> Detect eye 3-> Detect finger print 4-> Detect voice', 3, 4),
(16, '43 * 55 = ', '1-> (2365) 2-> (2356) 3-> (2563)', 1, 5),
(17, '9 * 728 =', '1-> (2556) 2-> (6554) 3->(4556) 4->(6552)', 4, 5),
(18, '22 * 99 =', '1-> (2178) 2-> (2718) 3-> (3718) 4-> (3178)', 1, 5),
(19, '11 * 99 =', '1-> (1029) 2-> (2034) 3-> (1089) 4->(2019)', 3, 5),
(20, 'Bear has how many teeth?', '1-> (32) 2-> (42) 3-> (50) 4-> (57)', 2, 6),
(21, 'An ostrich\'s eye is bigger than its ______ ?', '1-> Brain 2-> lungs 3-> wings', 1, 6),
(22, 'Goldfish can see ?', '1-> Infrared 2-> ultravoilet 3-> both 4-> none', 3, 6),
(23, 'Cats spend 66% of their life _______?', '1-> Eating 2-> sleeping 3-> playing 4-> wall climbing', 2, 6),
(24, '_____ has steel wires equal to the earth\'s circumference ?', '1-> Great wall of china 2-> Pyramid 3-> Bandra Worli Sealink', 3, 7),
(25, '______ is the highest cricket ground in the world ?', '1-> Himachal Pradesh 2-> Brisbane 3-> Gymkhana', 1, 7),
(26, 'Shampooing is an _______ concept?', '1-> Chinease 2-> American 3-> Japanease 4-> Indian', 4, 7),
(27, 'Water on the moon was discovered by ____?', '1-> America 2-> India 3-> Japan 4-> Russia', 2, 7),
(28, 'Tickets numbered 1 to 20 are mixed up and then a ticket is drawn at random. What is the probability that the ticket drawn has a number which is a multiple of 3 or 5?', '1-> (1/2) 2->(2/5) 3-> (8/15) 4-> (9/20)', 4, 8),
(29, 'A and B can do a job together in 7 days. A is 13/4 times as efficient as B. The same job can be done by A alone in :', '1-> 9(1/3) 2-> (11) 3-> 12(1/4) 4-> 16(1/3)', 2, 8),
(30, 'Which of the following has the most number of divisors?', '1-> (99) 2-> (101) 3-> (176) 4-> (182)', 3, 8),
(31, 'Two cards are drawn together from a pack of 52 cards. The probability that one is a spade and one is a heart, is:', '1-> (3/20) 2-> (29/34) 3-> (47/100) 4-> (13/102)', 4, 8);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_question_type`
--

CREATE TABLE `tbl_question_type` (
  `level` int(11) NOT NULL,
  `threshhold_time` int(11) NOT NULL,
  `mark_weight` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_question_type`
--

INSERT INTO `tbl_question_type` (`level`, `threshhold_time`, `mark_weight`) VALUES
(1, 90, 2),
(2, 180, 4),
(3, 270, 6),
(4, 360, 8),
(5, 450, 10),
(6, 540, 12),
(7, 630, 14),
(8, 720, 16);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_result_ato101`
--

CREATE TABLE `tbl_result_ato101` (
  `id` int(6) UNSIGNED NOT NULL,
  `exam_id` int(11) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL,
  `selected_option` int(11) DEFAULT NULL,
  `result` varchar(10) DEFAULT NULL,
  `hit_time` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_result_ato101`
--

INSERT INTO `tbl_result_ato101` (`id`, `exam_id`, `question_id`, `selected_option`, `result`, `hit_time`) VALUES
(1, 1, 3, 4, 'pass', '21/12/2016 19:02:22'),
(2, 1, 7, 4, 'pass', '21/12/2016 19:02:22'),
(3, 1, 14, 4, 'pass', '21/12/2016 19:02:22'),
(4, 1, 10, 3, 'pass', '21/12/2016 19:02:22');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_test_results`
--

CREATE TABLE `tbl_test_results` (
  `exam_id` int(11) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `started_time` varchar(30) NOT NULL,
  `ended_time` varchar(30) DEFAULT NULL,
  `score` double DEFAULT NULL,
  `max_mark` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_test_results`
--

INSERT INTO `tbl_test_results` (`exam_id`, `user_id`, `started_time`, `ended_time`, `score`, `max_mark`) VALUES
(1, 'ato101', '21/12/2016 19:02:22', '21/12/2016 19:02:22', 20, 20);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_roles`
--

CREATE TABLE `tbl_user_roles` (
  `count` int(11) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `user_role` int(11) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user_roles`
--

INSERT INTO `tbl_user_roles` (`count`, `user_id`, `user_role`, `user_name`, `password`) VALUES
(4, 'ATO100', 0, 'Gowtham', 'Admin'),
(5, 'ATO101', 1, 'jagadesh', '321');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_test`
--

CREATE TABLE `tbl_user_test` (
  `count` int(11) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `hall_ticket` tinyint(1) NOT NULL,
  `max_mark` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user_test`
--

INSERT INTO `tbl_user_test` (`count`, `user_id`, `hall_ticket`, `max_mark`) VALUES
(1, 'ATO101', 0, 20);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_question_bank`
--
ALTER TABLE `tbl_question_bank`
  ADD PRIMARY KEY (`count`);

--
-- Indexes for table `tbl_question_type`
--
ALTER TABLE `tbl_question_type`
  ADD UNIQUE KEY `Unique_level` (`level`),
  ADD UNIQUE KEY `Unique_Time` (`threshhold_time`);

--
-- Indexes for table `tbl_result_ato101`
--
ALTER TABLE `tbl_result_ato101`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_test_results`
--
ALTER TABLE `tbl_test_results`
  ADD PRIMARY KEY (`exam_id`);

--
-- Indexes for table `tbl_user_roles`
--
ALTER TABLE `tbl_user_roles`
  ADD PRIMARY KEY (`count`),
  ADD UNIQUE KEY `Unique_ID` (`user_id`);

--
-- Indexes for table `tbl_user_test`
--
ALTER TABLE `tbl_user_test`
  ADD PRIMARY KEY (`count`),
  ADD UNIQUE KEY `Unique_ID` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_question_bank`
--
ALTER TABLE `tbl_question_bank`
  MODIFY `count` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `tbl_result_ato101`
--
ALTER TABLE `tbl_result_ato101`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_test_results`
--
ALTER TABLE `tbl_test_results`
  MODIFY `exam_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_user_roles`
--
ALTER TABLE `tbl_user_roles`
  MODIFY `count` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_user_test`
--
ALTER TABLE `tbl_user_test`
  MODIFY `count` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_user_test`
--
ALTER TABLE `tbl_user_test`
  ADD CONSTRAINT `tbl_user_test_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_user_roles` (`user_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
