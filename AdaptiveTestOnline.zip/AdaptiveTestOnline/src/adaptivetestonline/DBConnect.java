/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adaptivetestonline;

import java.sql.*;
import java.util.*;

/**
 *
 * @author Ultimate Server
 */
public class DBConnect {

    public Connection con_open;
    public Statement con_stmt;
    public ResultSet con_resultset;
    private int $sec = 0;

    //Objects*************
    Scanner _scan = new Scanner(System.in);
    Timer _myTimer = new Timer();
    //Objects**************

    public DBConnect() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con_open = DriverManager.getConnection("jdbc:mysql://localhost:3306/ato", "root", "");
            con_stmt = con_open.createStatement();
        } catch (Exception ex) {
            System.out.println("Error @ DBconnect: " + ex);
        }
    }

    //for login
    public int getAuthentication(String id, String password) {
        int $$role = -1;
        String $$pwd = "";
        try {
            String query = "select user_role, user_id, password from tbl_user_roles where user_id = '" + id + "' and password = '" + password + "'";
            con_resultset = con_stmt.executeQuery(query);
            while (con_resultset.next()) {
                $$pwd = con_resultset.getString("password");
                $$role = con_resultset.getInt("user_role");
            }
        } catch (Exception ex) {
            System.err.println("Error " + ex);
        }

        if (($$pwd == null ? password != null : !$$pwd.equals(password))) {
            return -1;
        } else {
            return $$role;
        }
    }

    //to get username
    public String getUserName(String id) {
        String $$name = "";
        try {
            con_resultset = con_stmt.executeQuery("select user_name from tbl_user_roles where user_id = '" + id + "'");
            while (con_resultset.next()) {
                $$name = con_resultset.getString("user_name");
            }
        } catch (Exception ex) {
            System.err.println("Error : " + ex);
        }
        return $$name;
    }

// for registration
    public void newUser() {
        System.out.println("Enter user_name:");
        String $$name = _scan.next();
        System.out.println($$name + " is Admin or not? (y/n)");
        String $$role_YN = _scan.next();
        int $$role;
        if ("y" == $$role_YN || $$role_YN == "Y") {
            $$role = 0;
            System.out.println($$name + " will be treated as Admin");
        } else {
            $$role = 1;
            System.out.println($$name + " will be treated as TestTaker");
        }
        boolean $$flag = false; //this is for password do while loop
        String $$id = "";
        do {
            System.out.println("Enter password:");
            String $$password = _scan.next();
            System.out.println("Re-Enter password:");
            String $$rePassword = _scan.next();
            if ($$password == null ? $$rePassword == null : $$password.equals($$rePassword)) {
                try {
                    con_resultset = con_stmt.executeQuery("select MAX(user_id) from tbl_user_roles");
                    while (con_resultset.next()) {

                        $$id = con_resultset.getString("MAX(user_id)");
                    }
                    //Making auto generating user_id
                    $$id = $$id.replace("ATO", "");
                    int $$$count = Integer.parseInt($$id.trim());
                    $$$count += 1;
                    $$id = "ATO" + $$$count;
                    //inserting to 1st table
                    PreparedStatement preparedStmt1 = con_open.prepareStatement("insert into tbl_user_roles (user_id,user_role,user_name,password) values (?,?,?,?)");
                    preparedStmt1.setString(1, $$id);
                    preparedStmt1.setInt(2, $$role);
                    preparedStmt1.setString(3, $$name);
                    preparedStmt1.setString(4, $$password);
                    preparedStmt1.execute();
                    //inserting to 2nd table
                    PreparedStatement preparedStmt2 = con_open.prepareStatement("insert into tbl_user_test (user_id,hall_ticket,max_mark) values(?,?,?) ");
                    preparedStmt2.setString(1, $$id);
                    preparedStmt2.setInt(2, 0);
                    preparedStmt2.setInt(3, 100);
                    preparedStmt2.execute();
                    //creating new user table
                    String $$temp = "tbl_result_" + $$id;
                    PreparedStatement preparedStmt3 = con_open.prepareStatement("CREATE TABLE " + $$temp + " (id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,exam_id int,question_id int,selected_option int,result varchar(10), hit_time varchar(20))");
                    preparedStmt3.executeUpdate();
                    System.err.println("NOTE : " + $$name + " is sucessfully registered. \n USER_ID : " + $$id + "\n PASSWORD : " + $$password);
                    $$flag = true;
                } catch (Exception ex) {
                    System.err.println("Error while registration: Invalid input");
                }
            } else {
                System.err.println("Check your password");
            }
        } while ($$flag = !true);
    }

    //For view specific user details
    public void getProfile(String id) {
        try {
            String $$$id = null, $$$query = "";
            if (id == null) {
                $$$query = "select * from tbl_user_roles";
            } else {
                $$$query = "select * from tbl_user_roles where user_id = '" + id + "'";
            }
            con_resultset = con_stmt.executeQuery($$$query);
            while (con_resultset.next()) {
                System.out.println("  --------------------------------------------------");
                $$$id = con_resultset.getString("user_id");
                System.out.println(" User_id : " + $$$id);
                System.out.println(" User_role : " + con_resultset.getInt("user_role"));
                System.out.println(" User_Name : " + con_resultset.getString("user_name"));
                System.out.println(" Password : " + con_resultset.getString("password"));
            }
            System.out.println("Do you want to modify anything? (y/n)");
            String $$$modify = _scan.next();
            if ("y".equals($$$modify) || "Y".equals($$$modify)) {
                if (id == null) {
                    System.out.println("Enter Valid user_ID : ");
                    modifyProfile(_scan.next());
                } else {
                    modifyProfile(id);
                }
            } else {
                System.out.println(" <- Going Back");
            }
        } catch (Exception ex) {
            System.err.println(" Invalid Input");
        }
    }

    //modify the name / pwd / role
    public void modifyProfile(String id) {
        int $$option = 0;
        do {
            try {
                System.out.println("Modify Profile (Select any option) :\n1-> User_role :\n2-> User_Name :\n4-> Back :");
                $$option = _scan.nextInt();
                switch ($$option) {
                    case 1:
                        System.out.println("Do you want to Change User role as Admin ? (y/n)");
                        String $$$Temp_role = _scan.next();
                        int $$$role;
                        if ("y".equals($$$Temp_role) || "Y".equals($$$Temp_role)) {
                            System.out.println("Modifying as admin");
                            $$$role = 0;
                        } else {
                            System.out.println("Modifying as Test Taker");
                            $$$role = 1;
                        }
                        PreparedStatement preparedstmt1 = con_open.prepareStatement("update tbl_user_roles set user_role = ? where user_id = '" + id + "'");
                        preparedstmt1.setInt(1, $$$role);
                        preparedstmt1.execute();
                        break;
                    case 2:
                        System.out.println("Enter UserName : ");
                        String $$$name = _scan.next();
                        PreparedStatement preparedstmt2 = con_open.prepareStatement("update tbl_user_roles set user_name = ? where user_id = '" + id + "'");
                        preparedstmt2.setString(1, $$$name);
                        preparedstmt2.execute();
                        System.out.println("Modified user name successfully!!!");
                        break;
                    case 3:
                        $$option = 3;
                        System.out.println("<- Going back");
                        break;
                    default:
                        System.err.println("Incorrect Input!");
                }
            } catch (Exception ex) {
                System.err.println("Invalid Entry");
            }

        } while ($$option < 3);
    }

    //changing pasword for both admin and test 
    public void changePassword(String id) {
        try {
            System.out.println("Enter New_Password : ");
            String $$$password = _scan.next();
            System.out.println("Re-Enter New_Password : ");
            String $$$rePassword = _scan.next();
            if ($$$password == null ? $$$rePassword == null : $$$password.equals($$$rePassword)) {
                PreparedStatement preparedstmt3 = con_open.prepareStatement("update tbl_user_roles set password = ? where user_id = '" + id + "'");
                preparedstmt3.setString(1, $$$rePassword);
                preparedstmt3.execute();
                System.out.println("Modified password successfully!!!");
            } else {
                System.out.println("password mismatch / null");
            }
        } catch (Exception ex) {
            System.err.println("Invalid input");
        }
    }

    //HallTicket: enable_disable
    public void accessHallTicket(int count) {
        String $$id = "", $$permission = "";
        int $$hallticket = 0;
        try {
            System.out.println("Do you want to (provid/refuse) Hall ticket? (y/n)['y'->provide/'n'->refuse]");
            $$permission = _scan.next();
            if ("y".equals($$permission) || "Y".equals($$permission)) {
                $$hallticket = 1;
            } else {
                $$hallticket = 0;
            }
            if (count == 0) {
                PreparedStatement preparedstmt1 = con_open.prepareStatement("update tbl_user_test set hall_ticket = ?");
                preparedstmt1.setInt(1, $$hallticket);
                preparedstmt1.execute();
            } else {
                System.out.println("Enter valid user_id : ");
                $$id = _scan.next();
                PreparedStatement preparedstmt1 = con_open.prepareStatement("update tbl_user_test set hall_ticket = ? where user_id = ?");
                preparedstmt1.setInt(1, $$hallticket);
                preparedstmt1.setString(2, $$id);
                preparedstmt1.execute();
            }
            System.out.println("Updated Sussesfully!");
        } catch (Exception ex) {
            System.err.println("invalid Input");
        }
    }

    //refuse hallticket after test compleation
    public void refuseHallTicket(String user_id) {
        try {
            PreparedStatement preparedstmt1 = con_open.prepareStatement("update tbl_user_test set hall_ticket = ? where user_id = ?");
            preparedstmt1.setInt(1, 0);
            preparedstmt1.setString(2, user_id);
            preparedstmt1.execute();
        } catch (Exception ex) {
            System.err.println("Invalid Input");
        }
    }

    // change maximum mark
    public void accessMaxMark(int count) {
        String $$id = "";
        int $$maxmark = 0;
        try {
            System.out.println("Enter Maximum Mark :");
            $$maxmark = _scan.nextInt();
            if (count == 0) {
                PreparedStatement preparedstmt1 = con_open.prepareStatement("update tbl_user_test set max_mark = ?");
                preparedstmt1.setInt(1, $$maxmark);
                preparedstmt1.execute();
            } else {
                System.out.println("Enter valid user_id : ");
                $$id = _scan.next();
                PreparedStatement preparedstmt1 = con_open.prepareStatement("update tbl_user_test set max_mark = ? where user_id = ?");
                preparedstmt1.setInt(1, $$maxmark);
                preparedstmt1.setString(2, $$id);
                preparedstmt1.execute();
            }
            System.out.println("Updated Sussesfully!");
        } catch (Exception ex) {
            System.err.println("Invalid input");
        }
    }

    //check for hall ticket & attemp test
    public void attemptTest(String id) {
        QuestionBank _qbank = new QuestionBank();
        int $$hallticket = 0, $$crt_option = 0, $$user_option = 0, $$level = 1, $$temp_sec = 0, $$qustion_no = 0, $$round = 0, $$exam_id = 0, $$max_level = 0, $$min_level = 0;
        double $$score = 0, $$max_mark = 0, $$frwd_buffer = 1, $$rev_buffer = 1;
        String $$result = null;
        try {
            // taking hall ticket
            con_resultset = con_stmt.executeQuery("select hall_ticket,max_mark from tbl_user_test where user_id='" + id + "'");
            while (con_resultset.next()) {
                $$hallticket = con_resultset.getInt("hall_ticket");
                $$max_mark = (double) con_resultset.getInt("max_mark");
            }
            // taking min level and maximum level for 
            con_resultset = con_stmt.executeQuery("select max(level),min(level) from tbl_question_type");
            while (con_resultset.next()) {
                $$max_level = con_resultset.getInt("max(level)");
                $$min_level = con_resultset.getInt("min(level)");
                $$level = $$min_level;
            }
            // checks for hall ticket
            if ($$hallticket > 0) {
                $$exam_id = _qbank.sessionOpen(id);
                // runs time eg: time left 10 sec.
                _myTimer.scheduleAtFixedRate(_task, 1000, 1000);
                do {
                    con_resultset = con_stmt.executeQuery("select * from tbl_question_bank where type = '" + $$level + "' ORDER BY RAND() LIMIT 1");
                    while (con_resultset.next()) {
                        $$round = $$round + _qbank.getWeight($$level);
                        if ($$round > $$max_mark) {
                            int $$Temp_round = $$round - _qbank.getWeight($$level);
                            $$Temp_round = (int) $$max_mark - $$Temp_round;
                            con_resultset = con_stmt.executeQuery("select * from tbl_question_bank WHERE type = ( select level FROM tbl_question_type WHERE mark_weight = '" + $$Temp_round + "')ORDER BY RAND() LIMIT 1");
                            while (con_resultset.next()) {
                                //dislay question with option for last question eg: if exam for 20 marks, if asked questions are 2,4,8 marks,
                                // then it will dislay question caries 6 mark instead of 16 mark as per concept.
                                $$qustion_no = con_resultset.getInt("count");
                                $$level = con_resultset.getInt("type");
                                System.out.println("Question    : " + con_resultset.getString("question"));
                                System.out.println("Options     : " + con_resultset.getString("options"));
                                $$crt_option = con_resultset.getInt("correct_option");
                                System.out.println("Enter option number : ");
                                $sec = _qbank.getThreshold($$level);
                                $$temp_sec = $sec;
                                $$user_option = _scan.nextInt();
                                if ($$crt_option == $$user_option) {
//                                    System.out.println("Correct :) ");
                                    if ($sec < 0) {
                                        $sec = $$temp_sec + (-$sec);
                                        $$score = $$score + (($$temp_sec / (double) $sec) * _qbank.getWeight($$level));
                                        System.out.println(" Your Score is (" + $$score + "/" + $$max_mark + ")");
                                    } else {
                                        $$score = $$score + _qbank.getWeight($$level);
                                        System.out.println(" Your Score is (" + $$score + "/" + $$max_mark + ")");
                                    }
                                    $$result = "pass";
                                } else {
//                                    System.out.println("InCorrect :( ");
                                    $$result = "fail";
                                }
                            }
                        } else {
                            //display question with option
                            $$qustion_no = con_resultset.getInt("count");
                            System.out.println("Question    : " + con_resultset.getString("question"));
                            System.out.println("Options     : " + con_resultset.getString("options"));
                            $$crt_option = con_resultset.getInt("correct_option");
                            System.out.println("Enter option number : ");
                            $sec = _qbank.getThreshold($$level);
                            $$temp_sec = $sec;
                            $$user_option = _scan.nextInt();
                            if ($$crt_option == $$user_option) {
//                                System.out.println("Correct :) ");
                                if ($sec < 0) {//marks calculation
                                    $sec = $$temp_sec + (-$sec);
                                    $$score = $$score + (($$temp_sec / (double) $sec) * _qbank.getWeight($$level));
                                    System.out.println(" Your Score is (" + $$score + "/" + $$max_mark + ")");
                                } else {
                                    $$score = $$score + _qbank.getWeight($$level);
                                    System.out.println(" Your Score is (" + $$score + "/" + $$max_mark + ")");
                                }
                                //question displaying logic
                                $$rev_buffer = 1;
                                $$level = $$level + (int) $$frwd_buffer;
                                $$frwd_buffer *= 2;
                                if ($$level > $$max_level) {
                                    $$level = $$max_level;
                                }
                                $$result = "pass";
                            } else {
//                                System.out.println("InCorrect :( ");
                                $$frwd_buffer = 1;
                                $$level = $$level - (int) $$rev_buffer;
                                $$rev_buffer *= 2;
                                if ($$level < $$min_level) {
                                    $$level = $$min_level;
                                }
                                $$result = "fail";
                            }
                        }
                        _qbank.updateUserResult(id, $$exam_id, $$qustion_no, $$user_option, $$result);
                        System.out.println("---------------------------------------------");
                    }
                } while ($$max_mark > $$round);
                //after test completion, it cancel time, refuse hall ticket and update mark in result
                _myTimer.cancel();
                refuseHallTicket(id);
                _qbank.sessionClose($$exam_id, $$score, (int) $$max_mark);
                System.out.println("Test Successfully Completed");

            } else {
                // if there is no hallticket found
                System.err.println("Please contact Admin(Santech) for Hall Ticket");
            }
        } catch (Exception ex) {
            System.err.println("No more attempts allowed");
        }
    }

    //for calculating test timing
    TimerTask _task = new TimerTask() {
        @Override
        public void run() {
            $sec -= 1;
//            System.out.println($sec + " Seconds left");
        }
    };

    //getResults
    public void getResult(String id, int overload) {
        String query = null;
        try {
            if (overload == 2) {
                id = "tbl_result_" + id.toLowerCase();
                query = "SELECT * FROM tbl_question_bank LEFT JOIN " + id + " ON tbl_question_bank.count=" + id + ".question_id WHERE exam_id != ''";
                con_resultset = con_stmt.executeQuery(query);
                while (con_resultset.next()) {
                    System.out.println(" exam_id :" + con_resultset.getString("exam_id"));
                    System.out.println(" Level :" + con_resultset.getString("type"));
                    System.out.println(" question :" + con_resultset.getString("question"));
                    System.out.println(" options :" + con_resultset.getString("options"));
                    System.out.println(" correct_option :" + con_resultset.getString("correct_option"));
                    System.out.println(" selected_option :" + con_resultset.getString("selected_option"));
                    System.out.println(" result :" + con_resultset.getString("result"));
                    System.out.println(" hit_time :" + con_resultset.getString("hit_time"));
                    System.out.println("-----------------------------");
                }
            } else {
                if (overload == 0) {
                    query = "select * from tbl_test_results";
                } else if (overload == 1) {
                    query = "SELECT * from tbl_test_results WHERE user_id = '" + id + "' ORDER by exam_id DESC";
                } else if (overload == 3) {
                    query = "SELECT * from tbl_test_results WHERE user_id = '" + id + "' ORDER by exam_id DESC LIMIT 1";
                }
                con_resultset = con_stmt.executeQuery(query);
                while (con_resultset.next()) {
                    System.out.println(" Exam_id :" + con_resultset.getString("exam_id"));
                    System.out.println(" user_id :" + con_resultset.getString("user_id"));
                    System.out.println(" Started Time :" + con_resultset.getString("Started_Time"));
                    System.out.println(" Ended Time :" + con_resultset.getString("Ended_Time"));
                    System.out.println(" Score :" + con_resultset.getString("score"));
                    System.out.println(" max_mark :" + con_resultset.getString("max_mark"));
                    System.out.println("-----------------------------");
                }
            }
        } catch (Exception ex) {
            System.err.println("Some thing went wrong !");
        }
    }
}
