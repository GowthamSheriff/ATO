/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adaptivetestonline;

import java.text.*;
import java.util.*;

/**
 *
 * @author Santech
 */
public class AdaptiveTestOnline {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int $role;
        String $userID = "", $password = "";

        //objects *********
        Scanner _scan = new Scanner(System.in);
        Date _date = new Date();
        DBConnect _dbConnect = new DBConnect();
        //objects *********
        DateFormat _dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        System.out.println("************************************ ADAPTIVE TEST ONLINE ************************************");
        System.out.println("-------------------------------------" + _dateFormat.format(_date) + "------------------------------------");
        System.out.println("Enter UserID : ");
        $userID = _scan.nextLine();
        System.out.println("Enter Password : ");
        $password = _scan.nextLine();
        $role = _dbConnect.getAuthentication($userID.toUpperCase(), $password);
        if ($role == 0) {
            TestConductor _testcon = new TestConductor($userID);
        } else if ($role > 0) {
            TestTaker _testTake = new TestTaker($userID);
        } else {
            System.err.println("Invalid user id / password");
            System.exit(0);
        }
    }
}
