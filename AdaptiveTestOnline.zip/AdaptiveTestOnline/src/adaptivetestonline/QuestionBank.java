/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adaptivetestonline;

import java.sql.PreparedStatement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 *
 * @author Santech
 */
public class QuestionBank extends DBConnect {

    private int $testID = 0;

    //*********objects
    DateFormat _dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    Date _date = new Date();
    //*********objects

    //view questions
    public void viewQuestionBank() {
        try {
            System.out.println("********************* Question Bank *********************");
            con_resultset = con_stmt.executeQuery("select * from tbl_question_bank order by count asc");
            while (con_resultset.next()) {
                System.out.println(" Question No    :" + con_resultset.getInt("count"));
                System.out.println(" Question       :" + con_resultset.getString("question"));
                System.out.println(" Options        :" + con_resultset.getString("options"));
                System.out.println(" Corrrect option:" + con_resultset.getInt("correct_option"));
                System.out.println(" Question Type  :" + con_resultset.getInt("type"));
                System.out.println("-----------------------------------------");
            }
        } catch (Exception ex) {
            System.err.println("Something went wrong!");
        }
    }

    //for adding new question
    public void addNewQuestion() {
        String $$question = "", $$option = "";
        int $$correct_option = 0, $$type = 0;
        try {
            System.out.println("Enter the Question (eg: Current US President: ) : ");
            $$question = _scan.nextLine().toString();
            System.out.println("Enter the Options (eg: 1-> Barack obama 2-> clinton 3-> Trump etc,.) : ");
            $$option = _scan.nextLine().toString();
            System.out.println("Enter Correct Option (eg: 3) : ");
            $$correct_option = Integer.parseInt(_scan.nextLine());
            System.out.println("Enter Question Type(eg: 1) [Types : 1,2,3,4,5,6,7,8] : ");
            $$type = Integer.parseInt(_scan.nextLine());
            if ($$type > 0 && $$type < 9) {
                System.out.println("Questyon type : " + $$type);
                PreparedStatement preparedstmt = con_open.prepareStatement("Insert into tbl_question_bank (question,options,correct_option,type) values (?,?,?,?) ");
                preparedstmt.setString(1, $$question);
                preparedstmt.setString(2, $$option);
                preparedstmt.setInt(3, $$correct_option);
                preparedstmt.setInt(4, $$type);
                preparedstmt.execute();
                System.out.println("New Question added Successfully!!");
            } else {
                System.err.println("Please enter valid Question type!");
            }
        } catch (Exception ex) {
            System.err.println("Invalid input");
        }
    }

    // view question types
    public void viewQuestionTypes() {
        try {
            System.out.println("********************* Question Type *********************");
            con_resultset = con_stmt.executeQuery("select * from tbl_question_type order by level asc");
            while (con_resultset.next()) {
                System.out.println(" Level          :" + con_resultset.getInt("level"));
                System.out.println(" Threshold Time :" + con_resultset.getInt("threshhold_time"));
                System.out.println(" Mark weight    :" + con_resultset.getInt("mark_weight"));
                System.out.println("-----------------------------------------");
            }
        } catch (Exception ex) {
            System.err.println("Something Went Wrong");
        }
    }

    //get mark_weight by level
    public int getWeight(int level) {
        int $$mark = 0;
        try {
            con_resultset = con_stmt.executeQuery("select mark_weight from tbl_question_type where level ='" + level + "' ");
            while (con_resultset.next()) {
                $$mark = con_resultset.getInt("mark_weight");
            }
        } catch (Exception ex) {
            System.err.println("something went wrong");
        }
        return $$mark;
    }

    //get threshold time by level
    public int getThreshold(int level) {
        int $$sec = 0;
        try {
            con_resultset = con_stmt.executeQuery("select threshhold_time from tbl_question_type where level ='" + level + "' ");
            while (con_resultset.next()) {
                $$sec = con_resultset.getInt("threshhold_time");
            }
            System.out.println("Time for this Question is :" + $$sec + " seconds \nYour Time starts now : \n");
        } catch (Exception ex) {
            System.err.println("something went wrong!");
        }
        return $$sec;
    }

    //update user result
    public void updateUserResult(String id, int exam_id, int qustion_no, int user_option, String result) {
        try {
            String $$name = ("tbl_result_" + id).toLowerCase();
            PreparedStatement preparedstmt = con_open.prepareStatement("insert into " + $$name + " (question_id,selected_option,result,exam_id,hit_time) values (?,?,?,?,?)");
            preparedstmt.setInt(1, qustion_no);
            preparedstmt.setInt(2, user_option);
            preparedstmt.setString(3, result);
            preparedstmt.setInt(4, exam_id);
            preparedstmt.setString(5, _dateFormat.format(_date));
            preparedstmt.execute();
        } catch (Exception ex) {
            System.out.println("some thing went wrong");
        }
    }

    //stores test stared time
    public int sessionOpen(String id) {
        int $$exam_id = 0;
        try {
            PreparedStatement preparedstmt = con_open.prepareStatement("insert into tbl_test_results (user_id, started_time) values (?,?)");
            preparedstmt.setString(1, id);
            preparedstmt.setString(2, _dateFormat.format(_date));
            preparedstmt.execute();
            con_resultset = con_stmt.executeQuery("select exam_id from tbl_test_results where started_time = '" + _dateFormat.format(_date) + "' and user_id ='" + id + "'");
            while (con_resultset.next()) {
                $$exam_id = con_resultset.getInt("exam_id");
            }
        } catch (Exception ex) {
            System.out.println("Some thing went wrong!");
        }
        return $$exam_id;
    }

    //stores test ended time
    public void sessionClose(int exam_id, double score, int max_mark) {
        try {
            PreparedStatement preparedstmt = con_open.prepareStatement("update tbl_test_results set ended_time = ?, score = ?, max_mark = ? where exam_id = '" + exam_id + "'");
            preparedstmt.setString(1, _dateFormat.format(_date));
            preparedstmt.setDouble(2, score);
            preparedstmt.setInt(3, max_mark);
            preparedstmt.execute();
        } catch (Exception ex) {
            System.out.println("Something went wrong!");
        }
    }
}
