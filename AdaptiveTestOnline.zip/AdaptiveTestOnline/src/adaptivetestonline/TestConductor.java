/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adaptivetestonline;

import java.util.Scanner;

/**
 *
 * @author Santech
 */
public class TestConductor {

    //Objects**************
    DBConnect _dbConnect = new DBConnect();
    Scanner _scan = new Scanner(System.in);
    QuestionBank _questionbank = new QuestionBank();
    //Objects**************
    private String $id;

    public TestConductor(String id) {
        this.$id = id;
        System.out.println(" Welcome " + _dbConnect.getUserName(id) + "(Admin)\n************************");;
        selectOption();
    }

    public void selectOption() {
        int $option = 0;
        try {
            do {
                System.out.println("TestConductor(select any option):\n1-> User Credentials :\n2-> Enable/Disable Test :\n3-> Maximim Mark :\n4-> Questions :\n5-> Results :\n6-> change Password :\n7-> Logout & quit :");
                $option = _scan.nextInt();
                switch ($option) {
                    case 1:
                        System.out.println(" User Credentials : *********************************************");
                        optionForCredientials();
                        break;
                    case 2:
                        System.out.println("Enable / Disable Test : *********************************************");
                        optionForHallTicket();
                        break;
                    case 3:
                        System.out.println("Maximum Mark : *********************************************");
                        optionForMaxMark();
                        break;
                    case 4:
                        System.out.println("Questions : *********************************************");
                        optionForQuestion();
                        break;
                    case 5:
                        System.out.println("Results : *********************************************");
                        optionForResult();
                        break;
                    case 6:
                        System.out.println("Change Password *********************************************");
                        _dbConnect.changePassword($id);
                        break;
                    case 7:
                        $option = 7;
                        System.out.println(_dbConnect.getUserName($id) + " Thank you for using :) ");
                        System.exit(0);
                    default:
                        System.err.println("Incorrect Input");
                        break;
                }
            } while ($option < 7);
        } catch (Exception ex) {
            System.err.println("Invalid Entry");
        }

    }

    public void optionForCredientials() {
        int $option = 0;
        do {
            try {
                System.out.println("User Credientials(select any option): \n1-> New user Registration :\n2-> View particular user:\n3-> View all user:\n4-> Back:");
                $option = _scan.nextInt();
                switch ($option) {
                    case 1:
                        System.out.println(" New User Registration : *********************************************");
                        _dbConnect.newUser();
                        break;
                    case 2:
                        System.out.println("View single Profile :  *********************************************");
                        System.out.println("Enter Valid user_id :");
                        _dbConnect.getProfile(_scan.next());
                        break;
                    case 3:
                        System.out.println("View All Profile : *********************************************");
                        _dbConnect.getProfile(null);
                        break;
                    case 4:
                        $option = 4;
                        System.out.println("<- Going back");
                        break;
                    default:
                        System.err.println("Incorrect Input!");
                }
            } catch (Exception ex) {
                System.err.println("Ivalid Entry!");
            }

        } while ($option < 4);
    }

    public void optionForHallTicket() {
        int $option = 0;
        do {
            try {
                System.out.println("Enable / Disable(select any option): \n1-> Provide/Refuse HallTicket for Single User :\n2-> Provide/Refuse HallTicket for Every User:\n3-> Back:");
                $option = _scan.nextInt();
                switch ($option) {
                    case 1:
                        System.out.println(" Provide/Refuse HallTicket for Single User : *********************************************");
                        _dbConnect.accessHallTicket(1);
                        break;
                    case 2:
                        System.out.println("Provide/Refuse HallTicket for Every User :  *********************************************");
                        _dbConnect.accessHallTicket(0);
                        break;
                    case 3:
                        $option = 3;
                        System.out.println("<- Going back");
                        break;
                    default:
                        System.err.println("Incorrect Input!");
                        break;
                }
            } catch (Exception ex) {
                System.err.println("Invalid Entry!");
            }

        } while ($option < 3);
    }

    public void optionForMaxMark() {
        int $option = 0;
        do {
            try {
                System.out.println("Maximum Mark(select any option): \n1-> Set Maximum Mark for Single User :\n2-> Set HallTicket for Every User:\n3-> Back:");
                $option = _scan.nextInt();
                switch ($option) {
                    case 1:
                        System.out.println(" Set Maximum Mark for Single User : *********************************************");
                        _dbConnect.accessMaxMark(1);
                        break;
                    case 2:
                        System.out.println("Set HallTicket for Every User :  *********************************************");
                        _dbConnect.accessMaxMark(0);
                        break;
                    case 3:
                        $option = 3;
                        System.out.println("<- Going back");
                        break;
                    default:
                        System.err.println("Incorrect Input!");
                        break;
                }
            } catch (Exception ex) {
                System.err.println("Invalid Entry!");
            }

        } while ($option < 3);
    }

    public void optionForQuestion() {
        int $option = 0;
        do {
            try {
                System.out.println("Question(select any option): \n1-> View Question Bank :\n2-> Add new Question :\n3-> View Question Types :\n4-> Exit :");
                $option = _scan.nextInt();
                switch ($option) {
                    case 1:
                        System.out.println(" View Question Bank : *********************************************");
                        _questionbank.viewQuestionBank();
                        break;
                    case 2:
                        System.out.println(" Add new Question :  *********************************************");
                        _questionbank.addNewQuestion();
                        break;
                    case 3:
                        System.out.println(" View Question Types :  *********************************************");
                        _questionbank.viewQuestionTypes();
                        break;
                    case 4:
                        $option = 4;
                        System.out.println("<- Going back");
                        break;
                    default:
                        System.err.println("Incorrect Input!");
                        break;
                }
            } catch (Exception ex) {
                System.err.println("Invalid Entry!");
            }

        } while ($option < 4);
    }

    public void optionForResult() {
        int $option = 0;
        do {
            try {
                System.out.println("Results(select any option): \n1-> View all Results :\n2-> View particular result :\n3-> View Detailed result :\n4-> Exit :");
                $option = _scan.nextInt();
                switch ($option) {
                    case 1:
                        System.out.println(" View all Results : *********************************************");
                        _questionbank.getResult(null, 0);
                        break;
                    case 2:
                        System.out.println(" View particular result :  *********************************************");
                        System.out.println("Enter valid user_id :");
                        _questionbank.getResult(_scan.next(), 1);
                        break;
                    case 3:
                        System.out.println(" View Detailed result :  *********************************************");
                        System.out.println("Enter valid user_id :");
                        _questionbank.getResult(_scan.next(), 2);
                        break;
                    case 4:
                        $option = 4;
                        System.out.println("<- Going back");
                        break;
                    default:
                        System.err.println("Incorrect Input!");
                        System.exit(0);
                        break;
                }
            } catch (Exception ex) {
                System.err.println("Invalid Entry!");
            }

        } while ($option < 4);
    }
}
