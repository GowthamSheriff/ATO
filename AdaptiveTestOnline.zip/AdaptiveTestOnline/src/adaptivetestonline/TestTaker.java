/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adaptivetestonline;

import java.util.Scanner;

/**
 *
 * @author Santech
 */
public class TestTaker {

    private String $id = "", $name = "";

    //Objects**************
    DBConnect _dbConnect = new DBConnect();
    Scanner _scan = new Scanner(System.in);
    QuestionBank _qbank = new QuestionBank();
    //Objects**************

    public TestTaker(String id) {
        this.$id = id;
        this.$name = _dbConnect.getUserName(id);
        System.out.println(" Welcome " + $name);
        selectOption();
    }

    public void selectOption() {
        int $$exam_id;
        int $$option = 0;
        do {
            System.out.println("TestTaker(select any option)\n1-> Do test :\n2-> View Results :\n3-> change Password :\n4-> Logout & quit :");
            $$option = _scan.nextInt();
            switch ($$option) {
                case 1:
                    System.out.println("********************************************* Welcome to Adaptive Test *********************************************");
                    _dbConnect.attemptTest($id);
                    break;
                case 2:
                    System.out.println("********************************************* Results *********************************************");
                    _dbConnect.getResult($id,3);
                    break;
                case 3:
                    System.out.println("********************************************* Change Password *********************************************");
                    _dbConnect.changePassword($id);
                    break;
                case 4:
                    $$option = 4;
                    System.out.println("<- Thank you " + $name + "->");
                    System.exit(0);
                default:
                    System.err.println("Incorrect Input!");
                    System.exit(0);
                    break;
            }
        } while ($$option < 4);
    }
}
